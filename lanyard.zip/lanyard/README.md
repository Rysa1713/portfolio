# Lanyard (React Three Fiber)

This is the interactive lanyard / badge demo using:
- React + Vite
- @react-three/fiber + drei
- @react-three/rapier physics
- meshline for the band

## Run
1) Install Node.js (LTS)
2) In this folder:

```bash
npm install
npm run dev
```

Open the URL Vite prints (usually http://localhost:5173).

## Notes
- The GLB model and band texture are loaded from assets.vercel.com via HTTPS.
