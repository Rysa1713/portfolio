import { useEffect } from "react"
import LanyardScene from "../components/LanyardScene"
import Bookshelf from "../components/BookShelf"
import "../styles/home.css"

export default function Home() {
  useEffect(() => {
  if (window.location.hash === "#bookshelf") {
    const el = document.getElementById("bookshelf")
    if (el) el.scrollIntoView({ behavior: "smooth" })

    // ✅ remove the hash so refresh goes back to the top
    window.history.replaceState(null, "", window.location.pathname)
  }
}, [])

 

  return (
    <main className="home">
      <section className="snap lanyardSection">
        <LanyardScene />
        <div className="scrollHint">Scroll ↓</div>
      </section>

      <section id="bookshelf" className="snap bookshelfSection">
        <Bookshelf />
      </section>
    </main>
  )
}

